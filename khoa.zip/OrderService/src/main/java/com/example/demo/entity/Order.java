package com.example.demo.entity;

public class Order {
	private String id;
	private String dateTime;
	public Order(String id, String dateTime) {
		super();
		this.id = id;
		this.dateTime = dateTime;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getDateTime() {
		return dateTime;
	}
	public void setDateTime(String dateTime) {
		this.dateTime = dateTime;
	}
	@Override
	public String toString() {
		return "Order [id=" + id + ", dateTime=" + dateTime + "]";
	}
	
	
	

}
